﻿using System.Collections;
using UnityEngine.UI;
using UnityEngine;

public class GenerateEnemy : MonoBehaviour {

    public GameObject enemy, win, lose;
    public DamselInDistress DamselGenerator;
    public Sprite covering;
    public int bullet, kills =0, Damsel_Kills = 0;
    public UI userInterface;
    public PlaySong song;
    public Vector3[] lokasiMusuh = new Vector3[3];
    int[] timer = new int[3];
    public DataList data;
    public GameObject[] magic;
    /*
     1. Fire
     2. Tornado/chop
     3. Aoe
     4. stun
     */

    public enum GameState
    {
        empty,
        attack,
        hide,
        stun
    }

    public enum WorldState
    {
        pause,
        run
    }

    public GameState [] curState = new GameState [3];
    public WorldState worldState = WorldState.run;

	// Use this for initialization
	void Start () {
        Time.timeScale = 1;
        data = FindObjectOfType<GameManager>().data;
        song.GetDataSound(data);
        bullet = PlayerData.bulletMax + Bonus.AddAmmo;
        worldState = WorldState.run;
        for (int i = 0; i < 3; i++)
        {
            timer[i] = 0;
            curState[i] = GameState.empty;
        }

        lokasiMusuh[0].Set(5.5f, 0f,0f);
        lokasiMusuh[1].Set(0f, 0f, 0f);
        lokasiMusuh[2].Set(-5.5f, 0f, 0f);
        for (int i = 0; i < 3; i++)
        {
            GenerateTheEnemy(i);
        }
    }

    void GenerateTheEnemy(int i)
    {
        curState[i] = GameState.attack;
        timer[i] = 0;
        GameObject musuh = Instantiate(enemy, lokasiMusuh[i], Quaternion.identity);
        musuh.GetComponent<EnemyBehavior>().ID = i;
        int a = Random.Range(1, 101);
        if (a < 20)
        {
            a = 1;
        }
        else a = 0;
        musuh.GetComponent<EnemyBehavior>().enemy = data.enemy[a];
        musuh.GetComponent<SpriteRenderer>().sprite = data.enemy[a].face;
        musuh.transform.parent = this.transform;

    }
	
	// Update is called once per frame
	void Update () {
        if(worldState == WorldState.run)
        {
            DamselGenerator.status = true;
            if (userInterface.playerSlider.value <= 0)
            {
                userInterface.playerSlider.value = 0;
                Time.timeScale = 0;
                lose.SetActive(true);
                userInterface.HUD.SetActive(false);
                userInterface.PHUD.SetActive(false);
                DamselGenerator.gameObject.SetActive(false);
                this.gameObject.SetActive(false);
            }
            else if (userInterface.Wave.value >= userInterface.Wave.maxValue)
            {
                userInterface.Wave.value = userInterface.Wave.value;
                Time.timeScale = 0;
                userInterface.IFWIN();
                DamselGenerator.gameObject.SetActive(false);
                userInterface.HUD.SetActive(false);
                userInterface.PHUD.SetActive(false);
                this.gameObject.SetActive(false);
            }
            for (int i = 0; i < 3; i++)
            {
                if (curState[i] == GameState.empty)
                {
                    if (timer[i] >= 200)
                    {
                        GenerateTheEnemy(i);
                    }
                    else
                    {
                        timer[i]++;
                    }
                }
            }
        }
        else DamselGenerator.status = false;

    }
}
