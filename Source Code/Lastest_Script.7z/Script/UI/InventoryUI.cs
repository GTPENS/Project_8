﻿using System.Collections;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InventoryUI : MonoBehaviour {

    public GameObject[] panel;
    public ActiveSlot[] slot;
    public Text getData;
    DataList data;
    public Image preview;
    Button[] buttoned;

    void Start()
    {
        //effect = FindObjectOfType<PassiveEffect>();
        data = FindObjectOfType<GameManager>().data;
        buttoned = panel[1].GetComponentsInChildren<Button>();
        Debug.Log(buttoned.Length);
        for (int temp = 0; temp < slot.Length; temp++)
        {
            try
            {
                slot[temp].slot.image.sprite = GameManager.gameManager.currentEquipment[temp].Picture;
                if (GameManager.gameManager.currentEquipment[temp] != null) getData.text = GameManager.gameManager.currentEquipment[temp].EffectDes;
                else getData.text = "";
            }
            catch
            {
                slot[temp].slot.image.sprite = null;
            }
                if (slot[temp].active)
                {
                    preview.sprite = slot[temp].slot.image.sprite;
                }
                for (int i = 0; i < buttoned.Length; i++)
                {
                    if (buttoned[i].image.sprite == slot[temp].slot.image.sprite)
                    {
                        buttoned[i].enabled = false;
                        //break;
                    }
                    Debug.Log("s");
                    foreach (Equipment item in data.cosplayer)
                    {
                        if (buttoned[i].image.sprite == item.Picture)
                        {
                            Debug.Log("c");
                            if(item.Unlocked!=true)buttoned[i].gameObject.SetActive(false);
                        }
                    }

                }

        }

        //temp = 0;
        //for (int i = 0; i < buttoned.Length; i++)
        //{
        //    foreach (ActiveSlot item in slot)
        //    {
        //        if(buttoned[i].image.sprite == item.slot.image.sprite)
        //        {
        //            buttoned[i].enabled = false;
        //            temp++;
        //            break;
        //        }
        //    }
        //    if (temp == 3) break;
        //}
    }

    // Use this for initialization
    public void ChangeEquiptment () {
        panel[0].SetActive(false);
        panel[1].SetActive(true);
	}

    public void activeSlot(int a)
    {
        for (int i = 0; i < slot.Length; i++)
        {
            if (i == a)
            {
                slot[i].active = true;
                preview.sprite = slot[i].slot.image.sprite;
                if (GameManager.gameManager.currentEquipment[i] != null) getData.text = GameManager.gameManager.currentEquipment[i].EffectDes;
                else getData.text = "";
              //  GameManager.gameManager.Equip
            }
            else slot[i].active = false;
        }
    }
	
	// Update is called once per frame
	public void ChooseEquipment (Image a) {
        for (int i = 0; i < buttoned.Length; i++)
        {
            if (buttoned[i].image.sprite == preview.sprite)
            {
                buttoned[i].enabled = true;
                break;
            }
        }

        int index = 0;
        for (int i = 0; i < slot.Length; i++)
        {
            if (slot[i].active)
            {
                index = i;
                slot[i].slot.image.sprite = a.sprite;
                preview.sprite = slot[i].slot.image.sprite;
                a.GetComponent<Button>().enabled = false;
                break;
            }
        }

        foreach(Equipment it in data.cosplayer)
        {
            if(it.Picture == preview.sprite)
            {
                GameManager.gameManager.Equip(it, index);
                getData.text = it.EffectDes;
                break;
            }
            else
            {
                GameManager.gameManager.Equip(null, index);
                getData.text = "";
            }
        }

        panel[1].SetActive(false);
        panel[0].SetActive(true);
    }

    public void Goto()
    {
        Bonus.Reset();
        foreach (Equipment item in GameManager.gameManager.currentEquipment)
        {
            try
            {
                for (int i = 0; i < item.efek.Length; i++)
                {
                    PassiveEffect.PE.DoEffect(item.efek[i].effectName, item.efek[i].amount);
                }
            }
            catch
            {

            }

            //Sprite a = item.slot.image.sprite;
            //for (int i = 0; i < data.cosplayer.Length; i++)
            //{
            //   if(data.cosplayer[i].Char == a)
            //    {
            //        for (int b = 0; b < data.cosplayer[i].Effect.Length; b++)
            //        {
            //            effect.DoEffect(data.cosplayer[i].Effect[b].Effect, data.cosplayer[i].Effect[b].amount);
            //        }
            //        break;
            //   }
            //}
        }
        SceneManager.LoadScene("Main Menu");
    }
}

[System.Serializable]
public struct ActiveSlot
{
    public Button slot;
    public bool active;
}
