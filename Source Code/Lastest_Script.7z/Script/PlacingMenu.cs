﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class PlacingMenu : MonoBehaviour {
    [SerializeField] tweener[] anim;
    [SerializeField]  SpriteRenderer yumi;
    
  

    void Start()
    {
        
        for (int i = 0; i < anim.Length; i++)
        {
            if (anim[i].ease == Ease.Unset)
                anim[i].ease = Ease.OutBack;
            anim[i].obj.DOMove(anim[i].posisiAkhir, anim[i].waktu).SetDelay(anim[i].delay).SetEase(anim[i].ease);
        }
    }
}

[System.Serializable]
public class tweener
{
    public Transform obj;
    public Vector2 posisiAkhir;
    public float waktu = 0.75f;
    public float delay = 0;
    public Ease ease = Ease.OutBack;
}
