﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GetPlace : MonoBehaviour {

    //public Transform obj;
    public float x, y;
    // Use this for initialization
    void Start () {
        //obj = gameObject.GetComponent<Transform>();
        x = transform.position.x;
        y = transform.position.y;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
