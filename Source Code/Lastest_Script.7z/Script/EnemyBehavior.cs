﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System.Collections;

public class EnemyBehavior : MonoBehaviour
{
    public int ID;
    static int time_action, maxTime = 90;
    public GenerateEnemy generateEnemy;
    public Slider enemyHealth;
    Sprite sprite;
    Transform startPosition;
    public Enemy enemy;

    // Use this for initialization
    void Start()
    {
        startPosition = GetComponent<Transform>();
        sprite = GetComponent<SpriteRenderer>().sprite;
        generateEnemy = FindObjectOfType<GenerateEnemy>();
        generateEnemy.userInterface.EnemyHealthBar(ID, gameObject.GetComponent<EnemyBehavior>());
        InvokeRepeating("DamageToPlayer", 1f, enemy.PunchRate);
    }

    void BackToStart()
    {
        gameObject.transform.rotation = startPosition.rotation;
        gameObject.transform.position = generateEnemy.lokasiMusuh[ID];
    }

    void Shoot()
    {
        float chance2 = Random.Range(1, 101);
        if (generateEnemy.curState[ID] != GenerateEnemy.GameState.hide)
        {
            float chance = Random.Range(1, 101);
            if (chance<= Bonus.InstantKill)
            {
                Debug.Log("COK : "+chance);
                if(chance2>Bonus.ChanceFreeAmmo)generateEnemy.bullet--;
                generateEnemy.song.Firebullet();
                enemyHealth.value = 0;
            }
            else
            {
                if (chance2 > Bonus.ChanceFreeAmmo) generateEnemy.bullet--;
                int damage = PlayerData.Attack + Bonus.AddAttack;
                int critical = Random.Range(1, 101);
                damage = Random.Range(damage - 5, damage + 6);
                if(critical < Bonus.AddCriticalHit && Bonus.AddCriticalHit <= 0)
                {
                    damage += critical;
                }
                generateEnemy.song.Firebullet();
                enemyHealth.value = enemyHealth.value - damage;
            }

            //if (generateEnemy.bullet < 0)
            //{
            //    generateEnemy.bullet = 0;
            //}

            gameObject.GetComponent<Transform>().DOShakePosition(0.5f, 1, 10, 90, false, true).OnComplete(BackToStart);

            Enemy_HP_Reach_Zero();
        }
        else
        {
            if (chance2 > Bonus.ChanceFreeAmmo) generateEnemy.bullet--;
            generateEnemy.song.Firebullet(3);
        }
    }

    void DestroyThis()
    {
        generateEnemy.curState[ID] = GenerateEnemy.GameState.empty;
        generateEnemy.kills += 1;
        generateEnemy.userInterface.Wave.value++;
        Destroy(enemyHealth.gameObject);
        Destroy(this.gameObject);
    }

    public void Enemy_HP_Reach_Zero()
    {
        if (enemyHealth.value <= 0)
        {

            GetComponent<SpriteRenderer>().DOFade(0, 0.2f).OnComplete(DestroyThis);
            // Destroy(this.gameObject);
            //Destroy(enemyHealth.gameObject);
            //Destroy(this.gameObject);
        }
    }

    public void OnMouseDown()
    {
        int SpellID = generateEnemy.userInterface.ActiveSpell;
        bool Spell;

        try
        {
            Spell = generateEnemy.data.spell[SpellID].magic;
        }
        catch
        {
            Spell = false;
        }

        if (generateEnemy.worldState == GenerateEnemy.WorldState.run)
        {
            if (Spell)
            {
                if (generateEnemy.data.spell[SpellID].description=="Stun")
                {
                    generateEnemy.curState[ID] = GenerateEnemy.GameState.stun;
                    generateEnemy.userInterface.DestroySpell(null, ID, this);
                    //generateEnemy.data.spell[SpellID].magic = false;
                }
                else
                {
                    GameObject fire = SkillActive.skillActive.EffectSpell(generateEnemy.lokasiMusuh[ID], generateEnemy.magic[SpellID]);
                    // fire.transform.parent = generateEnemy.transform;
                    generateEnemy.userInterface.DestroySpell(fire, 0, null);
                    //generateEnemy.data.spell[SpellID].magic = false;
                }
                generateEnemy.data.spell[SpellID].magic = false;
                generateEnemy.userInterface.btnMagic[SpellID].SetActive(false);
            }
            else
            {
                        if (generateEnemy.bullet > 0)
                        {
                            Shoot();
                        }
                        else
                        {
                            CancelInvoke("TelltoShutOFF");
                            generateEnemy.song.EmptyBullet();
                            generateEnemy.userInterface.reloadNotif.gameObject.SetActive(true);
                            Invoke("TelltoShutOFF", 1);
                        }
                    
            }
        }
    }

    void TelltoShutOFF()
    {
        generateEnemy.userInterface.ReloadNotificationShutOFF();
    }

    void RestoreAlphaBlood()
    {
        generateEnemy.userInterface.blood.GetComponent<Image>().color = new Color(1, 1, 1, 1);
        //generateEnemy.userInterface.blood.SetActive(false);
    }

    void BloodShownShutOFF(){
        //generateEnemy.userInterface.blood.SetActive(false);\
        generateEnemy.userInterface.blood.GetComponent<Image>().DOFade(0, 1);

    }
	
	void BloodShown(){
        //CancelInvoke("BloodShownShutOFF");
        // RestoreAlphaBlood();
        //generateEnemy.userInterface.blood.SetActive(true);
        generateEnemy.userInterface.blood.GetComponent<Image>().color = new Color(1, 1, 1, 1);
        generateEnemy.userInterface.blood.GetComponent<Image>().DOFade(0, 2);
        //Invoke("BloodShownShutOFF", 1);
    }

    void Hide()
    {
        generateEnemy.curState[ID] = GenerateEnemy.GameState.hide;
        GetComponent<SpriteRenderer>().sprite = generateEnemy.covering;
    }

    void Attack()
    {
        generateEnemy.curState[ID] = GenerateEnemy.GameState.attack;
        GetComponent<SpriteRenderer>().sprite = sprite;
    }

    float Fungsi_Linear(float parameter, int Max, int Min, bool isUP = true)
    {
        int Range = Max - Min;
        if (isUP)
        {
            if (parameter > Max)parameter = 1;
            else if (Min < parameter && parameter < Max)
            {
                parameter -= Min;
                parameter = parameter / Range;
            }
            else if (parameter < Min)parameter = 0;
        }
        else {
            //turun
            if (parameter > Max)parameter = 0;
            else if (Min < parameter && parameter < Max)
            {
                parameter = Max - parameter;
                parameter = parameter / Range;
            }
            else if (parameter < Min)parameter = 1;
        }

        return parameter; 
    }

    struct Rule {
        public float predikat, total;
        float z;
        public void Compute(float a)
        {
            z = a;
            total = predikat * z;
        }
    }

    Rule [] aturan = new Rule[4];

    float inverse_Fungsi_Linear(float parameterA, float parameterB, int Max, int Min, int order, bool isUP = true)
    {
        int Range = Max - Min;
        float parameter = 0;
        if (parameterA < parameterB) parameter = parameterA;
        else parameter = parameterB;
        aturan[order].predikat = parameter;

        if (isUP)parameter = Min + parameter * Range;
        //turun
        else parameter = Max - parameter*Range;

        aturan[order].Compute(parameter);

        return parameter;
    }

    float Inverse_Fungsi_Kurva_Segitiga(float parameterA, float parameterB, int min, int max, int order)
    {
        float x;
        if (parameterA < parameterB) x = parameterA;
        else x = parameterB;
        aturan[order].predikat = x;

        float parameter = max + x*(max - min);
        //int Range = b - x;
        //b-=a;
        //Range = Range / b;
        aturan[order].Compute(parameter);

        return parameter;
    }

//Fuzzy tsukamoto
//Penerapan ada pada Update
    float Tsukamoto()
    {
        float m_Progress = generateEnemy.userInterface.Wave.value/generateEnemy.userInterface.Wave.maxValue * 100;
        float u_P_naik = Fungsi_Linear(m_Progress, 80, 20);
        float u_P_turun = Fungsi_Linear(m_Progress, 80, 20,false);

        float health = enemyHealth.value / enemyHealth.maxValue * 100;
        float u_H_naik = Fungsi_Linear(health, 30, 70);
        float u_H_turun = Fungsi_Linear(health, 30, 70, false);

        float rule1 = inverse_Fungsi_Linear(u_H_turun, u_P_turun, 50, 10, 0, false);

        float rule2 = Inverse_Fungsi_Kurva_Segitiga(u_H_turun, u_P_naik, 25, 50, 1);
        float rule3 = Inverse_Fungsi_Kurva_Segitiga(u_H_naik, u_P_turun, 50, 75, 2);

        float rule4 = inverse_Fungsi_Linear(u_H_naik, u_P_naik, 90, 50, 3);

        float A = 0, B = 0;
        for (int i = 0; i <4; i++)
        {
            A += aturan[i].total;
            B += aturan[i].predikat;
        }

        A = A / B;

        return A;
    }

    void Update()
    {
        if (time_action > maxTime)
        {
            time_action = 0;
            int chance = Random.Range(1, 101);
            if(generateEnemy.curState[ID] != GenerateEnemy.GameState.stun)
            {
                float debu = Tsukamoto();
                //Debug.Log(debu);
                if (chance <= debu)
                {
                    //Hide();
                    Attack();
                }
                else
                {
                    Hide();
                    //Attack();
                }
            }
            maxTime = Random.Range(30, 101);
        }
        else time_action++;
    }
	
	void DamageToPlayer() {
        if(generateEnemy.worldState == GenerateEnemy.WorldState.run)
        { 
            if (generateEnemy.curState[ID] != GenerateEnemy.GameState.hide && generateEnemy.curState[ID] != GenerateEnemy.GameState.stun)
            {
               generateEnemy.song.EnemyShoot();
                int damage = enemy.Damage;
                generateEnemy.userInterface.playerSlider.value = generateEnemy.userInterface.playerSlider.value - Random.Range(damage-5,damage+5);
				BloodShown();
            }
        }
    }

    ////void OnCollisionEnter2D(Collision2D e)
    ////{
    //    if (e.collider.tag == "spellHurt")
    //    {
    //        enemyHealth.value -= 30;
    //        Enemy_HP_Reach_Zero();
    //    }
    //}

    void OnTriggerEnter2D(Collider2D e)
    {
        //Debug.Log(e.gameObject.name);
        //if (e.gameObject.name == "enemy(Clone)")
        //{
        //    Debug.Log("JAncok");
        SkillActive.skillActive.Damage(enemyHealth, e.GetComponent<Damage>().damage);
        Enemy_HP_Reach_Zero();
        //}
    }
}
