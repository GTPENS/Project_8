﻿using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;
using System.Collections;

public class UI : MonoBehaviour {

    public Text kill_text, reloadNotif, MoneyScore;
    public Button gunReload;
    public GenerateEnemy GE;
    public Slider playerSlider,enemyHealthBar, Wave;
    public GameObject HUD, PHUD, ExitPanel, blood;
    public Image bg;
    public Sprite RedBar;
    public int levelID = 0, ActiveSpell = 99;
    float half;
    public GameObject[] btnMagic;
    /*
     1. Fire
     2. Tornado/chop
     3. Aoe
     4. stun
     */

    DataList data;

    public void IFWIN()
    {
        int money = (int)playerSlider.value;
        int chances = Random.Range(1, 101);
        int penalty = 20;

        if(Bonus.DamselPenaltyDecrease > 0)
        {
            penalty -= penalty * Bonus.DamselPenaltyDecrease / 100;
        }

        if (chances < Bonus.AddMoneyPercent)
        {
            money += money * chances / 100;
            money += chances;
            money -= (GE.Damsel_Kills * penalty);
            if (money <= 0) money = 0;
        }

        PlayerData.Money += money;
        MoneyScore.text = "" + money;

        GE.win.SetActive(true);
    }

    void SetBackground()
    {
        bg.sprite = data.levelData[0].BG;
    }

    void SetSkillActive()
    {
        int b = 0;
        for (int a = 0; a < Bonus.spellActive.Length; a++)
        {
                if (Bonus.spellActive[a].active) {
                Debug.Log("fuck");
                    btnMagic[a].transform.localPosition = data.btnSpell[b];
                btnMagic[a].SetActive(true);
                GE.magic[a].GetComponent<Damage>().damage = Bonus.spellActive[a].damage;
                    btnMagic[a].SetActive(true);
                    b++;
                  //  break;
                }
            
        }
    }

    void Start()
    {
        data = FindObjectOfType<GameManager>().data;
        Wave.maxValue = data.levelData[levelID].MaxKill;
        Wave.value = 0;

        GameManager.gameManager.Music_Detect();
        SetBackground();
        SetSkillActive();

        //SetHealth
        playerSlider.maxValue = PlayerData.Health + Bonus.AddHealth;
        playerSlider.value = playerSlider.maxValue;
    }

    public void GunReload()
    {
        GE.bullet = PlayerData.bulletMax + Bonus.AddAmmo;
        gunReload.gameObject.SetActive(false);
       // gunReload.onClick.Invoke();
    }
	
	// Update is called once per frame
	void Update () {
        //bullet_text.text = ""+GE.bullet;
        kill_text.text = "Bullet = " + GE.bullet + " Civillians Kills = "+GE.Damsel_Kills;
        if(GE.bullet <=0 && !gunReload.gameObject.active)
        {
            gunReload.gameObject.SetActive(true);
        }
        
        //if (half < 1000)
        //{
        //    //half = GE.data.levelData[levelID].MaxKill / GE.kills;
        //    if (GE.kills >= 30)
        //    {
        //       // bg.sprite = data.BG[1];
        //        //half = 1000;
        //    }
        //}

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ExitOrNot();
        }
	}

    public void EnemyHealthBar(int i, EnemyBehavior a)
    {
        Vector2 loc = a.gameObject.transform.position;
        loc.y = 2.5f;
        GameObject hud = Instantiate(enemyHealthBar.gameObject, loc, Quaternion.identity);
        hud.transform.parent = HUD.transform;
        hud.GetComponent<RectTransform>().localScale = new Vector3(1F, 1f, 0);
        hud.GetComponent<Slider>().maxValue = a.enemy.HP;
        hud.GetComponent<Slider>().value = hud.GetComponent<Slider>().maxValue;
        a.enemyHealth = hud.GetComponent<Slider>();
    }

    void ExitOrNot()
    {
        GE.worldState = GenerateEnemy.WorldState.pause;
        GE.gameObject.SetActive(false);
        HUD.SetActive(false);
        PHUD.SetActive(false);
        ExitPanel.SetActive(true);
    }

    public void Exit()
    {
        Application.Quit();
    }

    public void Continue()
    {
        ExitPanel.SetActive(false);
        GE.gameObject.SetActive(true);
        HUD.SetActive(true);
        PHUD.SetActive(true);
        GE.worldState = GenerateEnemy.WorldState.run;
    }

    public void ReloadNotificationShutOFF()
    { 
        reloadNotif.gameObject.SetActive(false);
    }

    public void BackMenu()
    {
        Time.timeScale = 1;
        GameManager.gameManager.Music_Detect();
        SceneManager.LoadScene("Main Menu");
    }

    IEnumerator Spell_is_Up(GameObject e)
    {
        yield return new WaitForSeconds(0.2f);
        Destroy(e.gameObject);
    }

    IEnumerator Stun_is_Up(EnemyBehavior e, int a)
    {
        SkillActive.skillActive.Stunned(e, true);
        yield return new WaitForSeconds(5);
        SkillActive.skillActive.Stunned(e, false);
        GE.curState[a] = GenerateEnemy.GameState.attack;
        //Destroy(e.gameObject);
    }

    public void DestroySpell(GameObject fire, int a, EnemyBehavior e)
    {
        if (fire == null)
        {
            if(GE.curState[a] == GenerateEnemy.GameState.stun)
            {
                StartCoroutine(Stun_is_Up(e, a));
            }
        }
        else StartCoroutine(Spell_is_Up(fire));
    }

    public void SpellButton(int a)
    {
        //SkillActive.skillActive.Fireball()
        
        if (GE.data.spell[a].magic)
        {
            GE.data.spell[a].magic = false;
            ActiveSpell = 99;
        }
        else
        {
            ActiveSpell = a;
            GE.data.spell[a].magic = true;
            for (int i = 0; i < GE.data.spell.Length; i++)
            {
                if(i!=a) GE.data.spell[i].magic = false;
            }
        }
    }
}
