﻿using UnityEngine;

public class GameManager : MonoBehaviour {
    #region Singleton
    public static GameManager gameManager;

    public DataList data;
    public AudioSource A;
    public AudioClip battle, menu;

    public void Music_Detect()
    {

        if (A.clip != battle)
        {
            A.Stop();
            A.clip = battle;
            A.Play();
        }
        else if (A.clip != menu)
        {
            A.Stop();
            A.clip = menu;
            A.Play();
        }
    }

    void Awake()
    {
        if (gameManager == null)
        {
            gameManager = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else if (gameManager != this)
        {
            Music_Detect();
            Destroy(this.gameObject);
        }
    }

    #endregion

    public Equipment[] currentEquipment;

    void Start()
    {
        int numSlots = 3;
        //System.Enum.GetNames(typeof(EquipmentSlot)).Length;
        if(currentEquipment.Length !=3) currentEquipment = new Equipment[numSlots];
        //currentEquipment = gameManager.currentEquipmentcurrentEquipment = new Equipment[numSlots]; }

    } 

   public void Equip(Equipment newItem, int a)
    {
        //for equipping item
        currentEquipment[a] = newItem;
    }

    // Use this for initializatio
}

[System.Serializable]
static class PlayerData
{
    //static public CardItem[] cardItem;
    public static int Health = 1000, Attack = 40, bulletMax = 6;
    public static int Money = 50000, Diamond = 10000;
}

[System.Serializable]
static class Bonus
{
    static public int AddHealth = 0, AddAttack = 0, ChanceFreeAmmo = 0;
    static public int InstantKill = 0, AddAmmo = 0, AddMoneyPercent = 0;
    static public int AddCriticalHit = 0, DamselPenaltyDecrease = 0;
    static SpellActive the_default = new SpellActive(false, 0);
    static public SpellActive [] spellActive = { the_default, the_default, the_default, the_default };
    /*
     1. Fire
     2. Tornado/chop
     3. Aoe
     4. stun
     */

    public static void Reset()
    {
        AddHealth = 0; AddAttack = 0; ChanceFreeAmmo = 0;
        InstantKill = 0; AddAmmo = 0; AddMoneyPercent = 0;
        AddCriticalHit = 0; DamselPenaltyDecrease = 0;
        for (int i = 0; i < spellActive.Length; i++)
        {
            spellActive[i] = the_default;
        }
    }

   
}
public struct SpellActive
{
    public bool active;
    public int damage;

    public SpellActive(bool bactive, int a)
    {
        active = bactive;
        damage = a;
    }
}