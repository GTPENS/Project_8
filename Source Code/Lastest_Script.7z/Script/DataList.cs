﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="DataListed",menuName ="DataList", order =1)]

public class DataList : ScriptableObject {

    public static DataList instance;

    [Header("Enemy List")]
    public Enemy[] enemy;

    [Header("Audio List")]
    public AudioClip[] sfx;

    [Header("Data Level List")]
    public LevelData[] levelData;

    [Header("Character Random")]
    public Equipment[] cosplayer;
    //public int DropChance;

    [Header("Magic Arts")]
    public MagicSpell[] spell;

    [Header("Button Magic Coordinate")]
    public Vector2[] btnSpell;
}

[System.Serializable]
public class LevelData
{
    public int MaxKill;
    public Sprite BG;
}

[System.Serializable]
public class MagicSpell
{
    public bool magic;
    public string description;
}

[System.Serializable]
public class Enemy
{
    public Sprite face;
    public int PunchRate, HP, Damage;
}
