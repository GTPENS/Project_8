﻿using GoogleMobileAds.Api;
using UnityEngine;
using System;

public class Iklan : MonoBehaviour {

    private InterstitialAd mInterstitialAd;

    private BannerView Bannerview;
    public RandomEvent Re;
    string RequestID = "ca-app-pub-6850360979752937~9538178591";
    string Interset = "ca-app-pub-6850360979752937/7499883209";
    string Banner = "ca-app-pub-6850360979752937/3951396720";
    // Use this for initialization
    void Awake () {
        MobileAds.Initialize(RequestID);
	}
	
	public void ShowAD()
    {
        //if (mInterstitialAd.IsLoaded())
        //{
        //    mInterstitialAd.Show();
        //}

        Bannerview = new BannerView(Banner, AdSize.Banner, AdPosition.Top);
        Bannerview.LoadAd(new AdRequest.Builder().Build());
        Bannerview.OnAdClosed += HandleOnAdClosed;
    }

    public void HandleOnAdClosed(object sender, EventArgs args)
    {
        //mInterstitialAd.LoadAd(new AdRequest.Builder().Build());
        Re.IncreasedDiamond();
    }

    //void RequestInterstitial()
    //{

    //}

}
