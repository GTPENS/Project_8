﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Animated : MonoBehaviour {
    //public GameObject[] Anim = new GameObject[10] ;
    // Use this for initialization
    public SpriteRenderer obj;

}
