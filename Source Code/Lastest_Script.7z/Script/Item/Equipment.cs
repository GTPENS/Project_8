﻿using System.Collections;
using UnityEngine.UI;
using UnityEngine;

[CreateAssetMenu(fileName = "New Card", menuName = "New Card")]
public class Equipment : ScriptableObject
{
    public Sprite Picture;
    //public EquipmentSlot equipSlot;
    public int TagRarity;
    public bool Unlocked;
    public Efek[] efek;
    public string EffectDes;

    public void Use()
    {

    }

    public void RemoveFromEquipment()
    {

    }
}

[System.Serializable]
public class Efek
{
    public EffectName effectName;
    public int amount;
    public bool active;
}
