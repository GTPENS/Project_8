﻿using UnityEngine.UI;
using System.Reflection;
using UnityEngine;

public enum EffectName
{
    AddATK,
    AddHP,
    InstantKill,
    AddAmmo,
    ChanceFreeAmmo,
    AddMoneyPercent,
    AddCritical,
    DamselPenaltyDecrease,
    Stun,
    Fire,
    Chop,
    AOE
}

public class PassiveEffect
{
    public static PassiveEffect PE = new PassiveEffect();
    public MethodInfo mi;
    bool Attach;
    int arg = 0;

    public void DoEffect(EffectName EN, int b)
    {
        //try
        //{
            arg = b;
            //Attach = pakai;
            mi = this.GetType().GetMethod(EN.ToString());
            mi.Invoke(this, null);
        //}
        //catch
        //{

        //}
    }

    public void DamselPenaltyDecrease()
    {
        Debug.Log("DamselPenaltyDecrease");
        Bonus.DamselPenaltyDecrease += arg;
    }

    public void AddCritical()
    {
        Debug.Log("AddCritical");
        Bonus.AddCriticalHit += arg;
    }

    public void AddATK()
    {
        Debug.Log("AddATK");
        Bonus.AddAttack += arg;
    }

    public void AddHP()
    {
        Debug.Log("AddHP");
        Bonus.AddHealth += arg;
    }

    public void InstantKill()
    {
        Debug.Log("InstantKill");
        Bonus.InstantKill += arg;
    }
    public void AddAmmo()
    {
        Debug.Log("AddAmmo");
        Bonus.AddAmmo += arg;
    }
    public void ChanceFreeAmmo()
    {
        Debug.Log("ChanceFreeAmmo");
        Bonus.ChanceFreeAmmo += arg;
    }
    public void AddMoneyPercent()
    {
        Debug.Log("AddMoneyPercent");
        Bonus.AddMoneyPercent += arg;
    }

    public void Stun()
    {
        Bonus.spellActive[3] = new SpellActive(true, arg);
    }

    public void Fire()
    {
        Debug.Log("Fire");
        Bonus.spellActive[0] = new SpellActive(true, arg);
    }

    public void Chop()
    {
        Bonus.spellActive[1] = new SpellActive(true, arg);
    }

    public void AOE()
    {
        Bonus.spellActive[2] = new SpellActive(true, arg);
    }
}

public class SkillActive : MonoBehaviour
{
    public static SkillActive skillActive = new SkillActive();

    public GameObject EffectSpell(Vector3 loc, GameObject e)
    {
        GameObject fire;
        if (e.name == "AOE")fire = Instantiate(e, Vector3.zero, Quaternion.identity);
        else fire = Instantiate(e, loc, Quaternion.identity);
        fire.name = e.name;
        fire.SetActive(true);
        // Invoke("Spell_is_Up", 2);
        return fire;
    }

    public void Damage(Slider e, int damage)
    {
        e.value -= damage;
    }

    public void Stunned(EnemyBehavior e, bool active)
    {
        if(active)e.GetComponent<SpriteRenderer>().color = new Color(0.36f, 0.13f, 0.82f);
        else e.GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f);
        //return e;
    }
}