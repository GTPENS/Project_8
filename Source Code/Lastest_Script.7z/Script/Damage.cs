﻿using UnityEngine;

public class Damage : MonoBehaviour {
    public int damage;
}
