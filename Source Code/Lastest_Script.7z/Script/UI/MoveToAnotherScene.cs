﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class MoveToAnotherScene : MonoBehaviour {
    public void GoTO(string a)
    {
        SceneManager.LoadScene(a);
    }

    public void QUIT_APP()
    {
        Application.Quit();
    }
}
