﻿using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;
using DG.Tweening;

public class RandomEvent : MonoBehaviour {

    DataList dt;
    public Image image;
    public Button[] images, left_rigtht;
    public Button returnFromGacha;
    public int stake, GachaKe;
    public GameObject one, ten, Menu, Menu2;
    public Text txtGold, txtDiamond;
    int gold, diamond;
    Vector3 left, right;
    Sprite emptySlot;

  //  DataList data;
    void Update()
    {
        txtGold.text = ""+gold;
        txtDiamond.text = "" + diamond;
    }

    void Start()
    {
        dt = GameManager.gameManager.data;
    }

    void Awake()
    {
        image.sprite = null;
        emptySlot = images[0].GetComponent<Image>().sprite;
        left = new Vector3(-9.0f, 0,0);
        right = new Vector3(9.0f, 0,0);
       // data = FindObjectOfType<DataList>();
        gold = PlayerData.Money;
        diamond = PlayerData.Diamond;
    }

    public void IfGacha10(Button a)
    {
        string name = a.name;
        if (name[0] == '1')
        {
            if (name == "10_Gold")
            {
                if (gold >= 30000)
                {
                    Menu.SetActive(false);
                    Menu2.SetActive(false);
                    gold -= 30000;
                    GachaKe = 0;
                    stake = 9;
                    one.SetActive(false);
                    ten.SetActive(true);
                }
            }
            else if (name == "10_Diamond")
            {
                if (diamond >= 2000)
                {
                    Menu2.SetActive(false);
                    Menu.SetActive(false);
                    diamond -= 2000;
                    GachaKe = 0;
                    stake = 9;
                    one.SetActive(false);
                    ten.SetActive(true);
                }

            }
        }
        else
        {
            if (name == "01_Gold")
            {
                if (gold >= 3000)
                {
                    Menu2.SetActive(false);
                    Menu.SetActive(false);
                    gold -= 3000;
                    one.SetActive(true);
                    ten.SetActive(false);
                }
            }
            else if (name == "01_Diamond")
            {
                if (diamond >= 200)
                {
                    Menu2.SetActive(false);
                    Menu.SetActive(false);
                    diamond -= 200;
                    one.SetActive(true);
                    ten.SetActive(false);
                }

            }
        }

    }

    public void Swap(Button a)
    {
        if (a.name == "left")
        {
            Menu.transform.DOMove(left, 1);
        }
        else if (a.name == "right")
        {
            Menu.transform.DOMove(right, 1);
        }
    }

    public void GachaSuper(int ID)
    {
        int A = Random.Range(1, 101);
        int[] kill = new int[50];
        int Max = 0;

        if (GachaKe==stake)
        {
            if (A > 95)
            {
                for (int i = 0; i < dt.cosplayer.Length; i++)
                {
                    if (dt.cosplayer[i].TagRarity == 5)
                    {
                        kill[Max] = i;
                        Max++;
                    }
                }
            }
            else
            {
                for (int i = 0; i < dt.cosplayer.Length; i++)
                {
                    if (dt.cosplayer[i].TagRarity == 15)
                    {
                        kill[Max] = i;
                        Max++;
                    }
                }
            }
            int B = Random.Range(0, Max);
            images[ID].GetComponent<Image>().sprite = dt.cosplayer[kill[B]].Picture;
            dt.cosplayer[kill[B]].Unlocked = true;
            returnFromGacha.gameObject.SetActive(true);
        }
        else
        {
            GachaBase(images[ID].GetComponent<Image>(), kill);
        }

        images[ID].enabled = false;
        GachaKe++;
    }

    void GachaBase(Image gambar, int [] kill)
    {
        int A = Random.Range(1, 101);
        int Max = 0;
        if (A < 3)
        {
            for (int i = 0; i < dt.cosplayer.Length; i++)
            {
                if (dt.cosplayer[i].TagRarity == 5)
                {
                    kill[Max] = i;
                    Max++;
                }
            }

        }
        else if (A >= 6 && A < 16)
        {
            for (int i = 0; i < dt.cosplayer.Length; i++)
            {
                if (dt.cosplayer[i].TagRarity == 15)
                {
                    kill[Max] = i;
                    Max++;
                }
            }
        }
        else
        {
            for (int i = 0; i < dt.cosplayer.Length; i++)
            {
                if (dt.cosplayer[i].TagRarity == 80)
                {
                    kill[Max] = i;
                    Max++;
                }
            }
        }

        int B = Random.Range(0, Max);

        gambar.sprite = dt.cosplayer[kill[B]].Picture;
        dt.cosplayer[kill[B]].Unlocked = true;
    }

    public void Gachabiasa(Button a){
        int[] kill = new int[50];
        GachaBase(image, kill);
        a.gameObject.SetActive(false);
        returnFromGacha.gameObject.SetActive(true);
	}

    public void ReturnFromGacha(Button a)
    {
        Menu2.SetActive(true);
        a.gameObject.SetActive(true);
        returnFromGacha.gameObject.SetActive(false);
        one.SetActive(false);
        ten.SetActive(false);
        Menu.SetActive(true);
        GachaKe = 0;
        stake = 9;
        image.sprite = null;
        foreach (Button item in images)
        {
            item.enabled = true;
            item.gameObject.GetComponent<Image>().sprite = emptySlot;
        }
    }

    public void GoTO(string a)
    {
        SceneManager.LoadScene(a);
        PlayerData.Money = gold;
        PlayerData.Diamond = diamond;
    }

    public void IncreasedDiamond()
    {
        diamond+=50;
        PlayerData.Diamond = diamond;
    }
}
